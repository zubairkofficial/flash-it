import { Component } from '@angular/core';

@Component({
  selector: 'app-flash-card-section',
  imports: [],
  templateUrl: './flash-card-section.html',
  styleUrl: './flash-card-section.css'
})
export class FlashCardSection {

}
